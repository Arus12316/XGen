import math
import json
import time
import socks
import socket
import struct
import random
import hashlib
import sqlite3
import requests
import datetime
import threading
import urbandict
import urllib.request
import ctypes
from xml.dom import minidom

# http://api.xgenstudios.com/?method=xgen.stickarena.stats.get&username={}
# http://api.xgenstudios.com/?method=xgen.users.changeName&username={}&password={}&new_username={}
# http://api.xgenstudios.com/?method=xgen.users.add&username={}&password={}&email_address={}&v=2
# http://api.xgenstudios.com/?method=xgen.users.addEmail&username={}&password={}&email={}
# http://api.xgenstudios.com/?method=xgen.users.changePassword&username={}&password={}&new_password={}

class SABot:
    def __init__(self, Username, Password, IP, Port, Commands):
        
        self.DatabaseConn = sqlite3.connect('BBH.db', check_same_thread=False)
        self.Database = self.DatabaseConn.cursor()

        self.Database.execute("""CREATE TABLE IF NOT EXISTS users
                            (username VARCHAR(20) UNIQUE COLLATE NOCASE NOT NULL,
                            rgb VARCHAR(9) NOT NULL,
                            hex VARCHAR(6) NOT NULL,
                            kills VARCHAR(30) NOT NULL,
                            deaths VARCHAR(30) NOT NULL,
                            wins VARCHAR(30) NOT NULL,
                            losses VARCHAR(30) NOT NULL,
                            rounds VARCHAR(30) NOT NULL,
                            ballistick BOOLEAN NOT NULL,
                            access BOOLEAN NOT NULL,
                            lastseen VARCHAR(30) NULL,
                            status BOOLEAN NOT NULL DEFAULT 0)
                            """)

        self.Database.execute("""CREATE TABLE IF NOT EXISTS blacklist
                            (username VARCHAR(20) UNIQUE COLLATE NOCASE NOT NULL,
                            color BOOLEAN NOT NULL,
                            location BOOLEAN NOT NULL)
                            """)

        self.DatabaseConn.commit()


        self.NullByte = struct.pack('B', 0)
        self.BufSize = 4096
        self.CommandChar = '!'
        self.InLobby = False
        self.AutoRespond = True
        self.OnlineUsers = {}
        self.OnlineUserMap = {}
        self.IDToUsername = {}
        self.UsernameToID = {}
        self.BotAdmin = 'Michal2' # set
        self.Dead = []
        self.Blacklist = [] # will ignore from specified users

        self.BadStatusCodes = [400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413,
                               414, 415, 416, 417, 500, 501, 502, 503, 504, 505]

        self.BotResponses = ['Lol, It\'s obvious', 'Obviously', 'Without a doubt', 'Yes, definitely', 'You may rely on it',
                            'As I see it, yes', 'Haha, most likely', 'Maybe', 'Yes', 'Hell yeah', 'No',
                            'Hmm.. no', 'I don\'t think so', 'Very doubtful', 'Ask someone who cares', 'Never',
                            'Probably', 'Did you think at least before asking this question', 'U wut m8', 'Idc', 'You really suck at asking questions',
                            'Please for the love of god leave me alone, you must be lonely', 'All signs point to yes, or maybe no.. actually Idk', 'N3rd is G.O.A.T is all you need to know']

        self.BotInsults = ['You suck', 'Is your ass jealous of the amount of shit that just came out of your mouth',
                           'I\'d like to see things from your point of view but I can\'t seem to get my head that far up my ass',
                           'Your birth certificate is an apology letter from the condom factory', 'You must have been born on a highway because that\'s where most accidents happen',
                           'If you really want to know about mistakes, you should ask your parents', 'It\'s better to let someone think you are an Idiot than to open your mouth and prove it', 'Which sexual position produces the ugliest children? Ask your mother', 'You so ugly when who were born the doctor threw you out the window and the window threw you back', 'You look uglier than TechSmart, nuff said', 'Timbo weighs more than you fatass']

        self.BotFacts = [''] #add bot facts
        
        self.NameToIP = {'Squaresville': '198.58.106.101:1031', 'Boxhead BLVD': '74.86.91.34:1031', 'Europe Block': '139.162.151.57:1031'}

        self.IPToName = {'198.58.106.101:1031': 'Squaresville', '74.86.91.34:1031': 'Boxhead BLVD', '139.162.151.57:1031': 'Europe Block'}

        self.BotPassword = Password
        self.ServerIP = IP
        self.ServerPort = Port
        self.Commands = Commands
        self.BotServer = self.IPToName[ '{}:{}'.format(self.ServerIP, self.ServerPort)]
        ctypes.windll.kernel32.SetConsoleTitleW("Boxhead Bounty hunter Chat and command Bot @Michal")

        self.connectToServer(Username, Password, self.ServerIP, self.ServerPort)

    def executeDatabaseQuery(self, Query, Parameters = None, ExecuteMany = False, ReturnResults = False):
        QueryFinished = False

        while not QueryFinished:
            try:
                if ExecuteMany and Parameters:
                    self.Database.executemany(Query, Parameters)
                else:
                    if Parameters:
                        self.Database.execute(Query, Parameters)
                    else:
                        self.Database.execute(Query)

                if ReturnResults:
                    QueryFinished = True
                    Results = self.Database.fetchall()

                self.DatabaseConn.commit()

                if 'Results' in locals():
                    return Results
                else:
                    return
            except sqlite3.OperationalError:
                pass
            except Exception as Error:
                QueryFinished = True

                print('[could not save query]: ' + Error)

    def changeUsername(self, Username, Password, NewUsername): # not implemented with bot commands
        APIData = {'username': Username, 'password': Password, 'new_username': NewUsername}
        RequestData = minidom.parseString(requests.get('http://api.xgenstudios.com/?method=xgen.users.changeName', params=APIData).text)
        Response = RequestData.getElementsByTagName('rsp')[0].attributes['stat'].value

        if Response == 'fail':
            return RequestData.getElementsByTagName('err')[0].attributes['msg'].value
        else:
            return 'Username successfully changed'

    def createAccount(self, Username, Password, UseAPI = False): # also not implemented with commands
        if UseAPI:
            APIData = {'username': Username, 'password': Password, 'v': '2'}
            URLData = requests.get('http://api.xgenstudios.com/?method=xgen.users.add', params=APIData).text
            Response = minidom.parseString(URLData).getElementsByTagName('rsp')[0].attributes['stat'].value

            if Response == 'fail':
                Returned = 'Could not create ' + Username
            else:
                Returned = 'Successfully created ' + Username
        else:
            PostData = {'username': Username, 'userpass': Password, 'usercol': '090090190', 'action': 'create'}
            URLData = requests.post('http://www.xgenstudios.com/stickarena/stick_arena.php', data=PostData).text

            if 'success' in URLData:
                Returned = 'Successfully created ' + Username
            else:
                Returned = 'Could not create ' + Username

        return Returned

    def sendPacket(self, Socket, PacketData, Receive = False):
        Packet = bytes(PacketData, 'utf-8')

        if Socket:
            Socket.send(Packet + self.NullByte)

            if Receive:
                return Socket.recv(self.BufSize).decode('utf-8')

    def startKeepAlive(self, TimerSeconds = 20):
        if hasattr(self, 'SocketConn'):
            KeepAliveTimer = threading.Timer(TimerSeconds, self.startKeepAlive)
            KeepAliveTimer.daemon = True
            KeepAliveTimer.start()

            self.sendPacket(self.SocketConn, '0')

    def sendPrivateMessage(self, UserID, Message):
        if UserID != self.BotID:
            if UserID in self.OnlineUsers:
                self.sendPacket(self.SocketConn, '00' + UserID + '91' + Message + 'c')

    def sendPublicMessage(self, Message):
        self.sendPacket(self.SocketConn, '91' + Message + 'C')

    def connectionHandler(self):
        Buffer = b''

        while hasattr(self, 'SocketConn'):
            try:
                Buffer += self.SocketConn.recv(self.BufSize)
            except OSError:
                if hasattr(self, 'SocketConn'):
                    self.SocketConn.shutdown(socket.SHUT_RD)
                    self.SocketConn.close()

            if len(Buffer) == 0:
                print('Disconnected')
                self.executeDatabaseQuery("UPDATE users SET status = 0")
                self.DatabaseConn.close()
                break
            elif Buffer.endswith(self.NullByte):
                Receive = Buffer.split(self.NullByte)
                Buffer = b''

                for Data in Receive:
                    Data = Data.decode('utf-8')

                    if Data.startswith('U'):
                        UserID = Data[1:][:3]
                        Username = Data[4:][:20].replace('#', '')

                        self.parseUserData(Data)
                    elif Data.startswith('D'):
                        UserID = Data[1:][:3]
                        Username = self.OnlineUsers[UserID]

                        self.executeDatabaseQuery("UPDATE users SET status = 0 WHERE username = ?", [(Username)])

                        CurrentInfo = '{}:{};{}'.format(self.ServerIP, self.ServerPort, time.strftime('%m/%d/%Y at %H:%M (EST)'))
                        self.executeDatabaseQuery("UPDATE users SET lastseen = ? WHERE username = ?", [(CurrentInfo, Username)], True)
                        
                        del self.OnlineUserMap[Username]
                        del self.OnlineUsers[UserID]
                    elif Data.startswith('M'):
                        UserID = Data[1:][:3]

                        self.parseUserMessage(UserID, Data)
                    elif Data.startswith('0g') or Data.startswith('0j'):
                        print('{{Server}}: {}'.format(Data[2:]))
                    elif Data.startswith('093'):
                        print('Secondary login')
                        break
                    elif Data.startswith('0f') or Data.startswith('0e'):
                        Time, Reason = Data[2:].split(';')
                        print('This account has just been banned [Time: {} / Reason: {}]'.format(Time, Reason))
                    elif Data.startswith('0c'):
                        print(Data[2:])
                    elif Data.startswith('01'):
                        for Room in Data[2:].split(';'):
                            self.RoomList = Data[5:].split(';')
                            print(self.RoomList)

    def connectToServer(self, Username, Password, ServerIP, ServerPort):
        if Username.lower() == '': # if running multiple bots, set to first one to ensure it doesn't reset the db users status
            self.executeDatabaseQuery("UPDATE users SET status = 0")

        try:
            self.SocketConn = socket.create_connection((ServerIP, ServerPort))
        except Exception as Error:
            print(Error)
            return

        Handshake = self.sendPacket(self.SocketConn, '08HxO9TdCC62Nwln1P', True).strip(self.NullByte.decode('utf-8'))

        if Handshake == '08':
            Credentials = '09{};{}'.format(Username, Password)
            RawData = self.sendPacket(self.SocketConn, Credentials, True).split(self.NullByte.decode('utf-8'))

            for Data in RawData:
                if Data.startswith('A'):
                    self.InLobby = True
                    self.BotID = Data[1:][:3]
                    self.BotUsername = Data[4:][:20].replace('#', '')

                    print('Bot Username: {} / Bot ID: {} / Located in {}'.format(self.BotUsername, self.BotID, self.BotServer))

                    EntryPackets = ['02Z900_', '03_']

                    for Packet in EntryPackets:
                        self.sendPacket(self.SocketConn, Packet)

                    self.startKeepAlive()
                    ConnectionThread = threading.Thread(target=self.connectionHandler)
                    ConnectionThread.start()
                    break
                elif Data == '09':
                    print('Incorrect password')
                    break
                elif Data == '091':
                    print('Currently banned')
                    break
        else:
            print('Server capacity check failed')

    def parseUserData(self, Packet, Password = None):
        StatsString = Packet.replace('\x00', '')
        UserID = StatsString[1:][:3]
        Type = StatsString[:1]
        
        if Type == 'U':
            if self.InLobby == True:
                Username = StatsString[4:][:20].replace('#', '')

                self.IDToUsername[UserID] = Username
                self.UsernameToID[Username] = UserID
            else:
                Username = StatsString[9:][:20].replace('#', '')

                self.IDToUsername[UserID] = Username
                self.UsernameToID[Username] = UserID

        if Type == 'U':
            if self.InLobby == True:
                Username = StatsString[4:][:20].replace('#', '')
                StatsString = StatsString[24:]

                self.OnlineUsers[UserID] = Username
                self.OnlineUserMap[Username] = UserID

                Stats = StatsString[9:].split(';')
                CurrentInfo = '{}:{};{}'.format(self.ServerIP, self.ServerPort, time.strftime('%m/%d/%Y at %H:%M (EST)'))
 
                self.executeDatabaseQuery("INSERT OR IGNORE INTO blacklist VALUES (?, ?, ?)", [(Username, '0', '0')], True)
            else:
                Username = StatsString[9:][:20].replace('#', '')

                self.OnlineUsers[UserID] = Username
                self.OnlineUserMap[Username] = UserID

    def parseUserMessage(self, SenderID, Packet):
        if SenderID in self.OnlineUsers:
            Sender = self.OnlineUsers[SenderID]

            if Sender in self.Blacklist:
                return

            NoUseTypes = ['1', '2', '4', '5', '6', '7', '8', '~', '?']
            MessageType = Packet[4:][:1]
            SenderMessage = Packet[5:]
            RawMessage = Packet[1:].replace(SenderID, '')

            if MessageType in NoUseTypes:
                return
            elif MessageType == '9' and not MessageType.startswith('?'):
                if self.Commands:
                    self.handleCommand(SenderID, Sender, SenderMessage, False)

    def handleCommand(self, SenderID, Sender, SenderMessage, Private):
        try:
            if 'C' in SenderMessage:
                if SenderMessage.startswith('1'):
                    SenderMessage = SenderMessage.replace('1', '')
                    SenderMessage = SenderMessage.split('C')
                    SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
                elif SenderMessage.startswith('2'):
                        SenderMessage = SenderMessage.replace('2', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
                elif SenderMessage.startswith('3'):
                        SenderMessage = SenderMessage.replace('3', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
                elif SenderMessage.startswith('4'):
                        SenderMessage = SenderMessage.replace('4', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
                elif SenderMessage.startswith('5'):
                        SenderMessage = SenderMessage.replace('5', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
                elif SenderMessage.startswith('6'):
                        SenderMessage = SenderMessage.replace('6', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
                elif SenderMessage.startswith('7'):
                        SenderMessage = SenderMessage.replace('7', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
                elif SenderMessage.startswith('8'):
                        SenderMessage = SenderMessage.replace('8', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])

                elif SenderMessage.startswith('9'):
                        SenderMessage = SenderMessage.replace('9', '')
                        SenderMessage = SenderMessage.split('C')
                        SenderMessage = '{}{}'.format(SenderMessage[1], SenderMessage[0])
            else:
                if not SenderMessage.startswith('?') and not 'C' in SenderMessage:
                    print("{} PM'd you.".format(Sender))
                    self.sendPrivateMessage(SenderID, "I cannot see your messages in PM system, use public chat, {}".format(Sender))
                    
        except IndexError:
            pass
        
        RespondByPM = (False if Private == False else True)
        Message = SenderMessage.strip()
        MessageCheck = Message.split()
        
        if Message.startswith(self.CommandChar):
            Command = MessageCheck[0][1:].lower()
            HasArguments = (True if len(MessageCheck) > 1 else False)
            Arguments = (' '.join(MessageCheck[1:]) if HasArguments else None)
            if Sender == self.BotAdmin:
                if Command == 'exec':
                    if HasArguments:
                        try:
                            exec(Arguments)
                        except Exception as Error:
                            print('{}'.format(Error))
                elif Command == 'reset':
                    RespondByPM = True

                    if HasArguments:
                        ResetTarget = MessageCheck[1].lower()

                        if ResetTarget == 'rr':
                            self.Dead = []

                            Response = 'Reset the list of the dead.'
                        elif ResetTarget == 'owner':
                            self.BotAdmin = None

                            Response = 'Reset bot owner.'
                        else:
                            Response = 'Invalid reset target.'
                    else:
                        self.Dead = []
                        self.BotAdmin = None

                        Response = 'Reset all items. You are no longer the current bot owner.'                

            if Command == 'blacklist':
                RespondByPM = True

                if HasArguments:
                    Target = Arguments.replace(' ', '').lower()
                    Username = Sender

                    Results = self.executeDatabaseQuery("SELECT * FROM blacklist WHERE username = ?", [(Username)], False, True)
                    if Results:
                        if Target == 'location':
                            Blacklisted = Results[0][2]

                            if Blacklisted:
                                self.executeDatabaseQuery("UPDATE blacklist SET location = 0 WHERE username = ?", [(Username)])
                                Response = 'Your location can now be publicly requested.'
                            else:
                                self.executeDatabaseQuery("UPDATE blacklist SET location = 1 WHERE username = ?", [(Username)])
                                Response = 'Your location can no longer be publicly requested.'
                else:
                    Username = Sender

                    Results = self.executeDatabaseQuery("SELECT * FROM blacklist WHERE username = ?", [(Username)], False, True)

                    if Results:
                        ColorBlacklisted = Results[0][1]
                        LocationBlacklisted = Results[0][2]

                        if ColorBlacklisted:
                            ColorBlacklisted = 0
                            self.executeDatabaseQuery("UPDATE blacklist SET color = 0 WHERE username = ?", [(Username)])
                        else:
                            ColorBlacklisted = 1
                            self.executeDatabaseQuery("UPDATE blacklist SET color = 1 WHERE username = ?", [(Username)])

                        if LocationBlacklisted:
                            LocationBlacklisted = 0
                            self.executeDatabaseQuery("UPDATE blacklist SET location = 0 WHERE username = ?", [(Username)])
                        else:
                            LocationBlacklisted = 1
                            self.executeDatabaseQuery("UPDATE blacklist SET location = 1 WHERE username = ?", [(Username)])

                        LocationBlacklisted = ('Your location can no longer be publicly requested' if LocationBlacklisted else 'Your location can be publicly requested')

                        Response = '{}'.format(LocationBlacklisted)
            elif Command == 'users':
                RespondByPM = True
                UserList = []

                for User in self.OnlineUserMap:
                    UserList .append(User)

                    Response = 'There are {} people in the lobby. Users: {}'.format(len(UserList), ', '.join(UserList))
            elif Command == 'stats':
                RespondByPM = True
                if HasArguments:
                    Arguments = Arguments.replace(' ', '')

                    if len(Arguments) <= 20:
                        Target = Arguments
                        Valid = True
                    else:
                        Response = 'Invalid username.'
                        Valid = False
                else:
                    Target = Sender
                    Valid = True

                if Valid:
                    APIURL = 'http://api.xgenstudios.com/?method=xgen.boxhead.users.stats&username={}'.format(Target)
                    APIData = minidom.parseString(requests.get(APIURL).text)
                    URLResp = APIData.getElementsByTagName('rsp')[0].attributes['stat'].value

                    if URLResp == 'ok':
                        RankTag = APIData.getElementsByTagName('rank')[0]
                        WinsTag = APIData.getElementsByTagName('wins')[0]
                        LossesTag = APIData.getElementsByTagName('losses')[0]
                        KillsTag = APIData.getElementsByTagName('kills')[0]
                        DeathsTag = APIData.getElementsByTagName('deaths')[0]
                        BountyTag = APIData.getElementsByTagName('bountyPoints')[0]

                        Rank = RankTag.childNodes[0].nodeValue
                        Wins = WinsTag.childNodes[0].nodeValue
                        Losses = LossesTag.childNodes[0].nodeValue
                        Kills = KillsTag.childNodes[0].nodeValue
                        Deaths = DeathsTag.childNodes[0].nodeValue
                        Bounty = BountyTag.childNodes[0].nodeValue

                        UserId = int(APIData.getElementsByTagName('user')[0].attributes['id'].value)

                        UserNew = ('Yes' if UserId > 20000000 else 'No')
                        StatsString = 'Wins: {} / Losses: {} / Kills: {} / Deaths: {} / Bounty Points: {} / Rank: #{} / New: {}'.format(Wins, Losses, Kills, Deaths, Bounty, Rank, UserNew)
                        Response = StatsString
                    else:
                        Response = '{} does not exist.'.format(Target)
                                                                
            elif Command == 'pm':
                if HasArguments and Sender == self.BotAdmin:
                    try:
                        RespondByPM = True
                        ID = '{}'.format(self.UsernameToID[Arguments.split()[0]])
                        Arguments1 = Arguments.replace(Arguments.split()[0], "")
                        pmMessage = Arguments1
                        exec(self.sendPrivateMessage(ID, pmMessage))
                    except KeyError:
                        RespondByPM = True
                        Response = 'This user isn\'t in lobby.'
                    except TypeError:
                        print('Message sent to "{}" : {}'.format(Arguments.split()[0], pmMessage))

            elif Command == 'fact':
                Response = random.choice(self.BotFacts)

            elif Command == 'choose':
                if HasArguments:
                    item1 = Arguments.split()[0]
                    item2 = Arguments.split()[2]
                    items = [item1, item2]
                    Response = "I chose " + random.choice(items)
                else:
                    RespondByPM = True
                    Response = "Usage: !choose Michal OR Mods"

            elif Command == 'calc':
                if HasArguments:
                    try:
                        if '+' in SenderMessage:
                            lol = exec('self.sendPublicMessage(str({}))'.format(Arguments))
                        elif '-' in SenderMessage:
                            lol = exec('self.sendPublicMessage(str({}))'.format(Arguments))
                        elif '^' in SenderMessage:
                            lol = exec('self.sendPublicMessage(str({}))'.format(Arguments))
                        elif '*' in SenderMessage:
                            lol = exec('self.sendPublicMessage(str({}))'.format(Arguments))
                        elif '/' in SenderMessage:
                            lol = exec('self.sendPublicMessage(str({}))'.format(Arguments))
                        else:
                            RespondByPM = True
                            Response = 'Use "+", "-", "*", "^" and "/" symbols.'
                    except TypeError:
                        pass
                    except SyntaxError:
                        pass
                    except NameError:
                        pass
                else:
                    RespondByPM = True
                    Response = "Usage: !calc 50+50"
                        

            elif Command == 'urban':
                if HasArguments:
                    try:
                        Arguments = Arguments.replace(' ', '')
                        query = Arguments
                        url = 'http://api.urbandictionary.com/v0/define?term=%s' % (query)
                        res = urllib.request.urlopen(url) 
                        data = json.loads(res.read().decode('utf-8'))
                        definition = data['list'][0]['definition']
                        Response = definition
                        if 'shit' in Arguments:
                            Response = 'One of the most popular swear/cuss/curse words/profanities' 
                        elif 'noob' in Arguments:
                            Response = 'Usually abused and misinterpreted name for a player that is bad on computer game'
                    except IndexError:
                        print("index error")
                        Response = 'There\'s no definition for this word.'
                    except urllib.error.URLError:
                        pass
            elif Command == 'love':
                if HasArguments:
                    try:
                        i = 1

                        while i<6:
                          i = i+1
                          princess = Arguments.split()[0]
                          n = 1

                          while n<6:
                            n = n+1
                            rnd = random.randint(1,20)
                            prince = Arguments.split()[2]
                            boy = (len(prince))
                            girl = (len(princess))
                            score = 100-(boy*girl)-rnd
                            Response = "Love result: " + str(score) + "%"
                    except IndexError:
                        RespondByPM = True
                        Response = "Incorrect command usage. Example : [USERNAME] and [USERNAME]"
                else:
                    RespondByPM = True
                    Response = "Usage: !love [USERNAME] and [USERNAME]"
            elif Command == 'commands':
                 RespondByPM = True
                 Response = 'The usable commands are: !stats | 8ball | !say | !create | !find | !id | !love | !help | !choose | !urban | !calc'

            elif Command == 'create':
                RespondByPM = True
                if HasArguments:
                    try:
                        Username = Arguments.split()[0]
                        Password = Arguments.split()[1]
                            
                        APIURL = 'http://api.xgenstudios.com/?method=xgen.users.add&username={}&password={}'.format(Username, Password)
                        APIData = minidom.parseString(requests.get(APIURL).text)
                        URLResp = APIData.getElementsByTagName('rsp')[0].attributes['stat'].value

                        if URLResp == 'ok':
                            StatsString = 'Successfully created ' + Username
                            Response = StatsString
                        else:
                            Response = 'Could not create ' + Username
                    except Exception as Error:
                        Response = 'Please specify your password.'
                else:
                    Response = "Usage: !create Michalisgod123 test"
            elif Command == 'say':
                if HasArguments:
                    Response = Arguments
                else:
                    RespondByPM = True
                    Response = "Usage: !say I love Michal"

            elif Command == 'id':
                RespondByPM = True
                if HasArguments:
                    Arguments = Arguments.replace(' ', '')

                    if len(Arguments) <= 20:
                                    Target = Arguments
                                    Valid = True
                    else:
                        Response = 'Invalid username.'
                        Valid = False
                else:
                    Target = Sender
                    Valid = True

                if Valid:
                    APIURL = 'http://api.xgenstudios.com/?method=xgen.stickarena.stats.get&username={}'.format(Target)
                    APIData = minidom.parseString(requests.get(APIURL).text)
                    URLResp = APIData.getElementsByTagName('rsp')[0].attributes['stat'].value
                    Username = APIData.getElementsByTagName('user')[0].attributes['username'].value

                    if URLResp == 'ok':
                        if Username != '':
                            StatTag = APIData.getElementsByTagName('user')

                            UserId = int(APIData.getElementsByTagName('user')[0].attributes['id'].value)                        

                            StatsString = 'UserID: {}'.format(UserId)

                            if len(StatsString) <= 135:
                                            Response = StatsString
                    else:
                        print('Stats string was too long to send')
                else:
                    Response = '{} does not exist.'.format(Arguments)

            elif Command == 'help':
                if HasArguments:
                    if Arguments == 'stats':
                        RespondByPM = True
                        Response = '!stats command is a command that allow you to lookup specified user account stats. Example: !stats Michal2'
                    else:
                        if Arguments == 'id':
                            RespondByPM = True
                            Response = '!id command is a command that allow you to lookup specified user account id to see if it\'s old or new. Example: !id Michal'
                        else:
                            if Arguments == 'love':
                                RespondByPM = True
                                Response = '!love command is a random love percentage calculator between two people. Example: !love raise and scam'
                            else:
                                if Arguments == 'calc':
                                    RespondByPM = True
                                    Response = '!calc command is a command that let you calculate something. Example: !calc 50+50'
                                else:
                                    if Arguments == 'choose':
                                        RespondByPM = True
                                        Response = 'Not sure what to chose? Ask bot! Example: !choose Michal or N3rd'
                                    else:
                                        if Arguments == '8ball':
                                            RespondByPM = True
                                            Response = 'Play with 8ball responses to your questions. Example: 8ball is raise ugly?'
                                        else:
                                            if Arguments == 'create':
                                                RespondByPM = True
                                                Response = 'Create new account using !create command. Example: !create raiseisugly password'
                                            else:
                                                if Arguments == 'urban':
                                                    RespondByPM = True
                                                    Response = 'Search definition for your word with urban dictionary! Example: !urban [WORD]'
                                                else:
                                                    if Arguments == 'say':
                                                        RespondByPM = True
                                                        Response = 'Make the bot say something. Example: !say raise is dumb asf'
                                                    else:
                                                        if Arguments == 'find':
                                                            RespondByPM = True
                                                            Response = 'Global find a user through servers or check his latest location. Example: !find Michal2'
                else:
                    RespondByPM = True
                    Response = "Usage: !help commandName Example: !help stats"
                            
            elif Command == 'rr':
                if Sender not in self.Dead:
                    GoodNumber = random.randint(0, 2)
                    BadNumber = random.randint(0, 2)

                    if GoodNumber == BadNumber:
                        self.Dead.append(Sender)
                        Response = 'You\'re dead, {}'.format(Sender)
                    else:
                        Response = 'You live, {}'.format(Sender)

            elif Command == 'clean':
                Mods = ['N3rd', 'Kendry', 'Champ24j', 'Michal2', 'Michal', 'Krux', 'Carlos', 'AngryNinny']
                if Sender in Mods:
                    url = 'http://api.urbandictionary.com/v0/define?term=shit'
                    res = urllib.request.urlopen(url) 
                    data = json.loads(res.read().decode('utf-8'))
                    definition = data['list'][0]['definition']
                    self.sendPublicMessage(definition)
                    time.sleep(1.5)
                    self.sendPublicMessage("Lobby chat messages successfully cleaned on {}'s request.".format(Sender))
                else:
                    RespondByPM = True
                    Response = "You need to be a moderator to use this command, {}.".format(Sender)

            elif Command == 'find':
                RespondByPM = True
                Response = 'Command usage: !find [USER]'

                if HasArguments:
                    Target = Arguments.replace(' ', '').lower()

                    if Target.startswith('*mod'): # will search for any user listed in db as status online and access level > 0
                        Results = self.executeDatabaseQuery("SELECT * FROM users WHERE access != 0", None, False, True)
                        
                        if Results:
                            OnlineMods = []

                            for Mod in Results:
                                if Mod[11] == 1:
                                    OnlineMods.append(Mod[0])

                            if len(OnlineMods) == 0:
                                Response = 'There are currently no mods online in any lobby I am located in.'
                            else:
                                Response = 'Online Mods: {}'.format(', '.join(OnlineMods))
                    else:
                        Results = self.executeDatabaseQuery("SELECT * FROM blacklist WHERE lower(username) = ?", [(Target.lower())], False, True)

                        if Results:
                            Username = Results[0][0]
                            Blacklisted = Results[0][2]

                            if Blacklisted and Sender != self.BotAdmin:
                                Response = '{} is not allowing requests for their location.'.format(Username)
                                Retrieve = False
                            else:
                                Retrieve = True
                        else:
                            Retrieve = True

                        if Retrieve:
                            Results = self.executeDatabaseQuery("SELECT * FROM users WHERE lower(username) = ?", [(Target)], False, True)
                            
                            if Results:
                                Username = Results[0][0]
                                LastSeen = Results[0][1]
                                Status = Results[0][2]

                                if LastSeen != None:
                                    Server, Time = LastSeen.split(';')
                                    ServerName = self.IPToName[Server]

                                    if Status == 1:
                                        Response = '{} is currently online in {}'.format(Username, ServerName)
                                    else:
                                        Response = '{} was last seen in {} on {}'.format(Username, ServerName, Time)
                                else:
                                    Response = '{} has no last seen record.'.format(Username)
                            else:
                                Response = 'No record is stored for "{}"'.format(Target)
                else:
                    Response = "Usage: !find Michal2"
        elif '8ball' in SenderMessage:
            if len(MessageCheck) >= 2 and len(MessageCheck[1]) >= 2:
                Response = '{}, {}'.format(random.choice(self.BotResponses), Sender)        
            
        if 'Response' in locals():
            try:
                if Private:
                    print('[PM from {} - "{}"] Response: {}'.format(Sender, SenderMessage, Response))
                else:
                    print('[{}] Response: {}'.format(Sender, Response))
                    
                if RespondByPM:
                    self.sendPrivateMessage(SenderID, Response)
                else:
                    self.sendPublicMessage(Response)
            except UnicodeEncodeError:
                RespondByPM = True
                self.sendPublicMessage('"{}" urban response contains unicode characters which can\'t go through BBH client'.format(Arguments))
                print('[{} - "UNICODE"]'.format(Sender))
            except UnicodeDecodeError:
                RespondByPM = True
                self.sendPublicMessage('"{}" urban response contains unicode characters which can\'t go through BBH client'.format(Arguments))
                print('[{} - "UNICODE"]'.format(Sender))
                
            except AttributeError:
                pass
        
if __name__ == '__main__': # username, pw, ip, port
    BBHBot('Michalbot3',  '', '198.58.106.101', 1031, True)
    BBHBot('Michalbot4',  '', '74.86.91.34', 1031, True)
    BBHBot('Michalbot5',  '', '139.162.151.57', 1031, True)
