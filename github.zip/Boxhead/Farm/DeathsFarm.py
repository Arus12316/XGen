import time
import socket
import struct
import threading
import ctypes

class FarmBot:
    def __init__(self, Username, Password, IP, Port):
        self.NullByte = struct.pack('B', 0)
        self.BufSize = 4096

        self.ServerIP = IP
        self.ServerPort = Port
        ctypes.windll.kernel32.SetConsoleTitleW("BBH Farm Bot (Collect Deaths) @Michal")

        self.connectToServer(Username, Password, self.ServerIP, self.ServerPort)

    def sendPacket(self, Socket, PacketData, Receive = False):
        Packet = bytes(PacketData, 'utf-8')

        if Socket:
            Socket.send(Packet + self.NullByte)

            if Receive:
                return Socket.recv(self.BufSize).decode('utf-8')
            
    def Farm(self, TimerSeconds = 2.7): # spawn time, 2.7 is the lowest server accepts. DO NOT DECREASE!
        if hasattr(self, 'SocketConn'):
            FarmTimer = threading.Timer(TimerSeconds, self.Farm)
            FarmTimer.daemon = True
            FarmTimer.start()
            
            self.sendPacket(self.SocketConn, '8034021')
            self.sendPacket(self.SocketConn, '6{}9999'.format(self.BotID))

    def connectionHandler(self):
        Buffer = b''

        while hasattr(self, 'SocketConn'):
            try:
                Buffer += self.SocketConn.recv(self.BufSize)
            except OSError:
                if hasattr(self, 'SocketConn'):
                    self.SocketConn.shutdown(socket.SHUT_RD)
                    self.SocketConn.close()

            if len(Buffer) == 0:
                print('Disconnected')
                break
            elif Buffer.endswith(self.NullByte):
                Receive = Buffer.split(self.NullByte)
                Buffer = b''

                for Data in Receive:
                    Data = Data.decode('utf-8')

                    if Data.startswith('0f') or Data.startswith('0e'):
                        Time, Reason = Data[2:].split(';')
                        print('This account has just been banned [Time: {} / Reason: {}]'.format(Time, Reason))
                    elif Data.startswith('0g') or Data.startswith('0j'):
                        print('{{Server}}: {}'.format(Data[2:]))
                    elif Data.startswith('093'):
                        print('Secondary login')
                        break

    def connectToServer(self, Username, Password, ServerIP, ServerPort):
        try:
            self.SocketConn = socket.create_connection((ServerIP, ServerPort))
        except Exception as Error:
            print(Error)
            return

        Handshake = self.sendPacket(self.SocketConn, '08HxO9TdCC62Nwln1P', True).strip(self.NullByte.decode('utf-8'))

        if Handshake == '08':
            Credentials = '09{};{}'.format(Username, Password)
            RawData = self.sendPacket(self.SocketConn, Credentials, True).split(self.NullByte.decode('utf-8'))

            for Data in RawData:
                if Data.startswith('A'):
                    self.BotID = Data[1:][:3]
                    self.BotUsername = Data[4:][:20].replace('#', '')

                    print('Logged in with: {} and ID: {}'.format(self.BotUsername, self.BotID))

                    EntryPackets = ['02Z900_', '03_', '02A01GAME;A', '04GAME', '0k1'] # GAME is the game name it creates, can be changed

                    for Packet in EntryPackets:
                        self.sendPacket(self.SocketConn, Packet)

                    ConnectionThread = threading.Thread(target=self.connectionHandler)
                    ConnectionThread.start()
                    self.Farm()
                    break
                elif Data == '09':
                    print('Incorrect password')
                    break
                elif Data == '091':
                    print('Currently banned')
                    break
        else:
            print('Server capacity check failed')
        
if __name__ == '__main__':
    FarmBot('',  '', '139.162.151.57', 1031) # username, pw, ip, port
