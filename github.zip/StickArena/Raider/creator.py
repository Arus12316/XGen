from urllib.request import urlopen
from urllib.parse import urlencode
import ctypes
ctypes.windll.kernel32.SetConsoleTitleW("StickArena Account Generator @Anubis")

 
def createAccount(Username, Password):
    Data = urlencode({"username": Username,
                                "userpass": Password,
                                "usercol": "255000000",
                                "action": "create"}).encode()
 
    Response = urlopen("http://www.xgenstudios.com/stickarena/stick_arena.php", Data).read().decode()
 
    if "success" in Response:
        Returned = "success"
    else:
        Returned = "fail"
 
    return Returned
 
if __name__ == "__main__":
    Username = "" # the username you want to make
    Password = "" # the password you want to login
 
    Current = 1 # if there was an error and your command line closed or something, you can change 1 to the number last account had and it will start from there
    Max = 500 # this can be increased, I don't think it matter
 
    while Current < Max:
        MassUsername = Username + str(Current)
 
        if createAccount(MassUsername, Password) == "success":
            Accounts = open("accounts.txt", "a+")
            Accounts.write("{};{}\n".format(MassUsername, Password))
            Accounts.close()
 
            print("Successfully created " + MassUsername)
        else:
            print("Failed to create " + MassUsername + "; moving on...")
 
        Current += 1
