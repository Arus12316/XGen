import sys
import time
import struct
import socket
import threading
 
class Raid:
    def __init__(self, Username, Password, IP, Port):
        self.NullByte = struct.pack("B", 0)
        self.BufSize = 4096

        ctypes.windll.kernel32.SetConsoleTitleW("StickArena Raider @Anubis")
 
        self.connectToServer(Username, Password, IP, Port)
 
    def sendPacket(self, Socket, PacketData, Receive = False):
        Packet = bytes(PacketData, "utf-8")
 
        if Socket:
            Socket.send(Packet + self.NullByte)
 
            if Receive:
                return Socket.recv(self.BufSize).decode("utf-8")
 
    def startKeepAlive(self, TimerSeconds = 20):
        if hasattr(self, "SocketConn"):
            KeepAliveTimer = threading.Timer(TimerSeconds, self.startKeepAlive)
            KeepAliveTimer.daemon = True
            KeepAliveTimer.start()
 
            self.sendPacket(self.SocketConn, "0")
 
    def connectionHandler(self):
        Buffer = b""
 
        while hasattr(self, "SocketConn"):
            try:
                Buffer += self.SocketConn.recv(self.BufSize)
            except OSError:
                if hasattr(self, "SocketConn"):
                    self.SocketConn.shutdown(socket.SHUT_RD)
                    self.SocketConn.close()
 
            if len(Buffer) == 0:
                print("Disconnected")
 
                try:
                    self.SocketConn.close()
                except:
                    pass
 
                break
            elif Buffer.endswith(self.NullByte):
                Receive = Buffer.split(self.NullByte)
                Buffer = b""
 
                for Data in Receive:
                    Data = Data.decode("utf-8")
 
                    if Data.startswith("0g") or Data.startswith("0j"):
                        print("{{Server}}: {}".format(Data[2:]))
                    elif Data.startswith("093"):
                        print("Secondary login")
 
                        break
                    elif Data.startswith("0f") or Data.startswith("0e"):
                        Time, Reason = Data[2:].split(";")
                        print("This account has just been banned [Time: {} / Reason: {}]".format(Time, Reason))
 
                        break
 
    def connectToServer(self, Username, Password, ServerIP, ServerPort):
        try:
            self.SocketConn = socket.create_connection((ServerIP, ServerPort))
        except Exception as Error:
            print(Error)
            return
 
        Handshake = self.sendPacket(self.SocketConn, "08HxO9TdCC62Nwln1P", True).strip(self.NullByte.decode("utf-8"))
 
        if Handshake == "08":
            Credentials = "09{};{}".format(Username, Password)
            RawData = self.sendPacket(self.SocketConn, Credentials, True).split(self.NullByte.decode("utf-8"))
 
            for Data in RawData:
                if Data.startswith("A"):
                    self.sendPacket(self.SocketConn, "02Z00_")
 
                    print(Username + " has been logged into " + ServerIP)
 
                    self.startKeepAlive()
 
                    ConnectionThread = threading.Thread(target=self.connectionHandler)
                    ConnectionThread.start()
 
                    RaidThread = threading.Thread(target=self.beginRaid)
                    RaidThread.daemon = True
                    RaidThread.start()
 
                    break
                elif Data == "09":
                    print("Incorrect password")
                    break
                elif Data == "091":
                    print("Currently banned")
                    break
                
    def beginRaid(self):
        time.sleep(120) # useful to not get banned by IP because accs will already be logged in
        self.sendPacket(self.SocketConn, '03_')
 
if __name__ == "__main__":
    with open("accounts.txt") as Accounts:
        for Account in Accounts:
            Username, Password = Account.replace("\n", "").split(";")
            IP = "74.86.43.9"
            Port = 1138
 
            Raid(Username, Password, IP, Port)
