# This bot is a banning machine that should stop or atleast help to stop annoying lobby raids
# Before you attempt to change anything here, please read Instructions.txt if you haven't already.
import socket
import struct
import threading
import time
import ctypes

class RaidBanner:
    def __init__(self, ModName, Password, IP, Port):
        
        ModName = '' 
        Password = ''
        
        IP = '74.86.43.9' # this is 2DC server ip, for list of all servers, go to servers.txt file
        Port = 1138 # server port never changes, only Cartesian Republic is an exception which port is 1139
        
        self.NullByte = struct.pack('B', 0)
        self.BufSize = 4096
        ctypes.windll.kernel32.SetConsoleTitleW("Ban StickArena Raiding Accounts @Michal")
        
        self.connectToServer(ModName, Password, IP, Port)

    def sendPacket(self, Socket, PacketData, Receive = False):
        Packet = bytes(PacketData, 'utf-8')

        if Socket:
            Socket.send(Packet + self.NullByte)

            if Receive:
                return Socket.recv(self.BufSize).decode('utf-8')

    def startKeepAlive(self, TimerSeconds = 20):
        if hasattr(self, 'SocketConn'):
            KeepAliveTimer = threading.Timer(TimerSeconds, self.startKeepAlive)
            KeepAliveTimer.daemon = True
            KeepAliveTimer.start()

            self.sendPacket(self.SocketConn, '0')

    def connectionHandler(self):
        Buffer = b''

        while hasattr(self, 'SocketConn'):
            try:
                Buffer += self.SocketConn.recv(self.BufSize)
            except OSError:
                if hasattr(self, 'SocketConn'):
                    self.SocketConn.shutdown(socket.SHUT_RD)
                    self.SocketConn.close()

            if len(Buffer) == 0:
                print('Disconnected')
                break
            elif Buffer.endswith(self.NullByte):
                Receive = Buffer.split(self.NullByte)
                Buffer = b''

                for Data in Receive:
                    Data = Data.decode('utf-8')

    def connectToServer(self, ModName, Password, IP, Port):
        try:
            self.SocketConn = socket.create_connection((IP, Port))
        except Exception as Error:
            print(Error)
            return

        Handshake = self.sendPacket(self.SocketConn, '08HxO9TdCC62Nwln1P', True).strip(self.NullByte.decode('utf-8'))

        if Handshake == '08':
            Credentials = '09{};{}'.format(ModName, Password)
            RawData = self.sendPacket(self.SocketConn, Credentials, True).split(self.NullByte.decode('utf-8'))

            for Data in RawData:
                if Data.startswith('A'):
                    self.BotID = Data[1:][:3]
                    self.BotUsername = Data[4:][:20].replace('#', '')

                    print('Logged in; Attempting to ban Raiding accounts ...\n')

                    EntryPackets = ['02Z900_', '03_']

                    for Packet in EntryPackets:
                        self.sendPacket(self.SocketConn, Packet)

                    self.startKeepAlive()
                    ConnectionThread = threading.Thread(target=self.connectionHandler)
                    ConnectionThread.start()
                    self.Ban()
                    break
                elif Data == '09':
                    print('Incorrect password')
                    break
                elif Data == '091':
                    print('Currently banned')
                    break
        else:
            print('Server capacity check failed')
            
    def Ban(self):
        time.sleep(2)
        Username = "" # username prefix you want to ban
 
        number = 1
        Max = 1000

        while number < Max:
            BanUsername = Username + str(number)
            BanReason = "" # put ban reason here
            self.sendPacket(self.SocketConn, '0f{};2620800;{}'.format(BanUsername, BanReason))
            try: 
                print("Successfully perma'd " + BanUsername)
                number += 1
            except KeyError:
                pass
        time.sleep(2)
        self.Ban()
        
if __name__ == '__main__':
    RaidBanner('', '', '74.86.43.9', 1138) # Mod username and Mod password, server ip and port.
