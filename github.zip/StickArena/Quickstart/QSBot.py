'''
ah yes, when run it will create a quick start room on each server with the supplied name
which is basically a takeover even though quick start is dead so also rest in pieces
'''

import time
import socks
import socket
import struct
import string
import random
import threading
import ctypes

class QSBot:
    def __init__(self, IP, Port, RoomName = 'BOT'):
        self.NullByte = struct.pack('B', 0)
        self.BufSize = 4096
        self.CommandChar = '.'
        self.OnlineUsers = {}
        self.OnlineUserMap = {}
        self.RoomName = RoomName
        self.KillCount = 0
        self.Alter = None
        self.Alting = False

        self.ServerIP = IP
        self.ServerPort = Port

        socks.setdefaultproxy(socks.PROXY_TYPE_SOCKS5, 'localhost', 9150)
        socket.create_connection = socks.create_connection
        socket.socket = socks.socksocket
        ctypes.windll.kernel32.SetConsoleTitleW("Random StickArena QuickStart Bot @Anubis")

        self.connectToServer(self.ServerIP, self.ServerPort)

    def sendPacket(self, Socket, PacketData, Receive = False):
        Packet = bytes(PacketData, 'utf-8')

        if Socket:
            Socket.send(Packet + self.NullByte)

            if Receive:
                return Socket.recv(self.BufSize).decode('utf-8')

    def startKeepAlive(self, TimerSeconds = 20):
        if hasattr(self, 'SocketConn'):
            KeepAliveTimer = threading.Timer(TimerSeconds, self.startKeepAlive)
            KeepAliveTimer.daemon = True
            KeepAliveTimer.start()

            self.sendPacket(self.SocketConn, '0')

    def sendPublicMessage(self, Message):
        self.sendPacket(self.SocketConn, '9' + Message)

    def connectionHandler(self):
        Buffer = b''

        while hasattr(self, 'SocketConn'):
            try:
                Buffer += self.SocketConn.recv(self.BufSize)
            except OSError:
                if hasattr(self, 'SocketConn'):
                    try:
                        self.SocketConn.shutdown(socket.SHUT_RD)
                        self.SocketConn.close()
                    except:
                        pass

            if len(Buffer) == 0:
                print('Disconnected')
                break
            elif Buffer.endswith(self.NullByte):
                Receive = Buffer.split(self.NullByte)
                Buffer = b''

                for Data in Receive:
                    Data = Data.decode('utf-8')

                    if Data.startswith('U'):
                        self.parseUserData(Data)
                    elif Data.startswith('D'):
                        UserID = Data[1:][:3]

                        try:
                            Username = self.OnlineUsers[UserID]

                            if Username == self.Alter:
                                self.Alting = False
                                self.Alter = None

                            print('{} left game on {}:{}'.format(Username, self.ServerIP, self.ServerPort))

                            del self.OnlineUserMap[Username]
                            del self.OnlineUsers[UserID]
                        except KeyError:
                            pass
                    elif Data.startswith('M'):
                        UserID = Data[1:][:3]

                        self.parseUserMessage(UserID, Data)
                    elif Data.startswith('0g') or Data.startswith('0j'):
                        print('{{Server}}: {}'.format(Data[2:]))
                    elif Data.startswith('0f') or Data.startswith('0e'):
                        Time, Reason = Data[2:].split(';')
                        print('This account has just been banned [Time: {} / Reason: {}]'.format(Time, Reason))

    def connectToServer(self, ServerIP, ServerPort):
        try:
            self.SocketConn = socket.create_connection((ServerIP, ServerPort), socks.PROXY_TYPE_SOCKS5, 'localhost', 9150)
        except Exception as Error:
            print(Error)
            return

        Handshake = self.sendPacket(self.SocketConn, '08HxO9TdCC62Nwln1P', True).strip(self.NullByte.decode('utf-8'))

        if Handshake == '08':
            Packets = ['01.', '02B100!{}'.format(self.RoomName), '04!{}'.format(self.RoomName), '05mp=77']

            for Packet in Packets:
                self.sendPacket(self.SocketConn, Packet)

            self.startKeepAlive()
            ConnectionThread = threading.Thread(target=self.connectionHandler)
            ConnectionThread.start()

            print('Connected.')
        else:
            print('Server capacity check failed.')

    def parseUserData(self, Packet, Password = None):
        StatsString = Packet.replace('\x00', '')
        UserID = StatsString[1:][:3]
        Type = StatsString[:1]

        if Type == 'U':
            Username = StatsString[9:][:20].replace('#', '')

            self.OnlineUsers[UserID] = Username
            self.OnlineUserMap[Username] = UserID

            self.sendPublicMessage('Hello! Type ".start"')
            print('{} joined game on {}:{}'.format(Username, self.ServerIP, self.ServerPort))

    def parseUserMessage(self, SenderID, Packet):
        if SenderID in self.OnlineUsers:
            Sender = self.OnlineUsers[SenderID]
            MessageType = Packet[4:][:1]
            SenderMessage = Packet[5:]
            RawMessage = Packet[1:].replace(SenderID, '')

            if MessageType == '9':
                self.handleCommand(SenderID, Sender, SenderMessage, False)
            elif MessageType == 'K':
                Kicker = Sender
                KickerID = SenderID

                if SenderMessage == self.BotID:
                    self.sendPublicMessage('{} is trying to kick me.'.format(Kicker))
                    return

                try:
                    ToKick = self.OnlineUsers[SenderMessage]
                except KeyError:
                    ToKick = None

                if ToKick != None:
                    ToKickID = SenderMessage

                    if ToKick in self.Allowed:
                        self.sendPublicMessage('Do not kick {}, {}.'.format(ToKick, Kicker))
                    else:
                        if Kicker in self.Allowed:
                            self.sendPublicMessage('Autokicking {}'.format(ToKick))
                            self.sendPacket(self.SocketConn, 'K{}'.format(ToKickID))
                        else:
                            self.sendPublicMessage('{} is trying to kick {}'.format(Kicker, ToKick))

    def handleCommand(self, SenderID, Sender, SenderMessage, Private):
        RespondByPM = (False if Private == False else True)
        Message = SenderMessage.strip()
        MessageCheck = Message.split()

        if Message.startswith(self.CommandChar):
            Command = MessageCheck[0][1:].lower()
            HasArguments = (True if len(MessageCheck) > 1 else False)
            Arguments = (' '.join(MessageCheck[1:]) if HasArguments else None)

            if Command == 'start':
                if not self.Alting:
                    print('{} started the autokill bot.'.format(Sender))

                    self.Alting = True
                    self.Alter = Sender

                    AltingThread = threading.Thread(target=self.startAltingBot, args=(SenderID, Sender))
                    AltingThread.daemon = True
                    AltingThread.start()

    def startAltingBot(self, UserID, Username):
        while self.Alting:
            if UserID in self.OnlineUsers:
                UserJoined = True
                Packets = ['509', '800500350', '6807000', '7{}7000'.format(UserID)]

                for Packet in Packets:
                    self.sendPacket(self.SocketConn, Packet)

                self.KillCount += 1
                time.sleep(1)

if __name__ == '__main__':
    RoomName = '~<>~'

    QSBot('74.86.43.9', 1138, RoomName)
    QSBot('74.86.43.8', 1138, RoomName)
    QSBot('198.58.106.101', 1138, RoomName)
    QSBot('69.164.207.72', 1138, RoomName)
    QSBot('139.162.151.57', 1138, RoomName)
    QSBot('45.56.72.83', 1138, RoomName)
    QSBot('198.58.106.101', 1139, RoomName)
